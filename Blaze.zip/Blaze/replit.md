# Overview

This is a fully functional Discord bot application built with Discord.js v14 that provides comprehensive server automation features. The bot enables server administrators to configure auto-responses, auto-reactions, and role assignment buttons within their Discord servers through intuitive slash commands. All configurations are persisted to a local JSON file and are server-specific (guild-scoped). The bot automatically restores all role button configurations on startup, ensuring seamless operation across restarts.

## Recent Changes
- October 3, 2025: Implemented complete Discord bot with slash commands, auto-responders, auto-reactions, and persistent role button system
- Added 9 slash commands for full configuration management
- Implemented role button restoration on bot startup
- Added comprehensive list and remove commands for all features

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
- **Technology**: Discord.js v14 with Node.js
- **Rationale**: Discord.js is the standard library for building Discord bots in JavaScript, providing comprehensive API coverage and active maintenance
- **Gateway Intents**: The bot uses specific intents (Guilds, GuildMessages, MessageContent, GuildMembers) to minimize memory footprint and comply with Discord's privileged intent requirements

## Command Architecture
- **Pattern**: Modular slash command system
- **Implementation**: Commands are dynamically loaded from the `/commands` directory using Node.js file system operations
- **Command Structure**: Each command exports a `data` property (SlashCommandBuilder) and an `execute` function
- **Dependency Injection**: Config object and saveConfig function are passed to command executors, allowing commands to read and persist state
- **Permissions**: All configuration commands require `ManageGuild` permission to prevent unauthorized modifications

## Data Storage
- **Solution**: File-based JSON storage (`config/data.json`)
- **Rationale**: Chosen for simplicity and zero external dependencies. Suitable for small to medium-scale deployments
- **Schema Structure**:
  - `autoResponders`: Guild-keyed object mapping keywords to response messages
  - `autoReactions`: Guild-keyed object mapping keywords to emoji reactions
  - `roleButtons`: Guild-keyed object mapping message IDs to button configurations
- **Limitations**: Not suitable for high-concurrency scenarios; no built-in backup/recovery mechanism
- **Alternatives Considered**: Database solutions (MongoDB, PostgreSQL) were likely not chosen to minimize setup complexity

## Message Processing
- **Auto-Responders**: Message content is checked against configured keywords; matching triggers automatic text responses
- **Auto-Reactions**: Message content is checked against configured keywords; matching triggers emoji reactions
- **Event Handling**: Uses Discord.js event system (likely `messageCreate` event, though implementation is incomplete in provided files)

## Interactive Components
- **Role Buttons**: Uses Discord.js ActionRow and ButtonBuilder to create interactive role assignment buttons
- **Button Persistence**: Button configurations are stored with message IDs, allowing the bot to handle interactions across restarts
- **Message Parsing**: Supports Discord message links with regex extraction of guild/channel/message IDs
- **Interaction Handling**: Likely uses `interactionCreate` event to handle button clicks (implementation incomplete in provided files)

## Configuration Management
- **Load Strategy**: Config is loaded once at startup with automatic directory/file creation if missing
- **Save Strategy**: Synchronous file writes after each configuration change
- **Default State**: Empty objects for all three feature categories
- **Multi-Server Support**: All features are namespaced by guild ID, allowing the bot to serve multiple Discord servers simultaneously

## Error Handling & Validation
- **Input Validation**: Commands validate message links using regex patterns
- **Permission Checks**: Guild ID validation prevents cross-server manipulation
- **Graceful Degradation**: Commands check for existence of configurations before attempting deletions
- **User Feedback**: All responses use ephemeral messages to keep configuration activities private

# External Dependencies

## Discord.js Library
- **Version**: ^14.22.1
- **Purpose**: Core Discord API wrapper providing bot functionality, gateway connections, slash commands, and interaction handling
- **Key Components Used**:
  - Client with Gateway Intents
  - SlashCommandBuilder for command registration
  - ActionRowBuilder and ButtonBuilder for interactive components
  - EmbedBuilder for rich message formatting
  - Permission flag bits for authorization

## Node.js Built-in Modules
- **fs (File System)**: Reading and writing configuration JSON, loading command modules
- **path**: Cross-platform file path resolution

## Discord Platform
- **Discord Gateway**: WebSocket connection for receiving events (messages, interactions)
- **Discord REST API**: Used by Discord.js for sending messages, editing messages, and managing interactions
- **Message Links**: Integration with Discord's message URL structure for cross-referencing messages

## Runtime Requirements
- **Node.js**: Version 16.11.0 or higher (required by Discord.js)
- **Environment**: Requires Discord bot token (not shown in repository, likely loaded via environment variables)