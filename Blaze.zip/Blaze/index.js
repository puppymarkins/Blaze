const { Client, GatewayIntentBits, Collection, Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionFlagsBits, ActivityType } = require('discord.js');
const express = require('express');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ]
});

client.commands = new Collection();

const configPath = path.join(__dirname, 'config', 'data.json');

function loadConfig() {
    if (!fs.existsSync(path.join(__dirname, 'config'))) {
        fs.mkdirSync(path.join(__dirname, 'config'));
    }
    
    if (!fs.existsSync(configPath)) {
        const defaultConfig = {
            autoResponders: {},
            autoReactions: {},
            roleButtons: {}
        };
        fs.writeFileSync(configPath, JSON.stringify(defaultConfig, null, 2));
        return defaultConfig;
    }
    
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

function saveConfig(config) {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

let config = loadConfig();

const app = express();
const PORT = 5000;

app.get('/', (req, res) => {
    res.send('Bot is online!');
});

app.get('/ping', (req, res) => {
    res.json({ 
        status: 'alive', 
        uptime: process.uptime(),
        bot: client.user ? client.user.tag : 'Not logged in'
    });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Web server running on port ${PORT}`);
});

const commandsPath = path.join(__dirname, 'commands');
if (!fs.existsSync(commandsPath)) {
    fs.mkdirSync(commandsPath);
}

const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
    }
}

client.once(Events.ClientReady, async () => {
    console.log(`Logged in as ${client.user.tag}`);
    
    client.user.setPresence({
        activities: [{
            name: "OG's aren't always better, I am.",
            type: ActivityType.Custom
        }],
        status: 'online'
    });
    
    const commands = [];
    for (const [name, command] of client.commands) {
        commands.push(command.data.toJSON());
    }
    
    try {
        await client.application.commands.set(commands);
        console.log(`Successfully registered ${commands.length} application commands.`);
    } catch (error) {
        console.error('Error registering commands:', error);
    }
    
    await restoreRoleButtons();
});

async function restoreRoleButtons() {
    let restoredCount = 0;
    let failedCount = 0;
    
    for (const [guildId, messages] of Object.entries(config.roleButtons)) {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) {
            console.log(`Skipping role buttons for guild ${guildId} (not found)`);
            continue;
        }
        
        for (const [messageId, data] of Object.entries(messages)) {
            try {
                const channel = await guild.channels.fetch(data.channelId);
                const message = await channel.messages.fetch(messageId);
                
                const buttons = data.buttons.map(btn =>
                    new ButtonBuilder()
                        .setCustomId(`role_${btn.roleId}`)
                        .setLabel(btn.label)
                        .setStyle(ButtonStyle.Primary)
                );
                
                const rows = [];
                for (let i = 0; i < buttons.length; i += 5) {
                    const row = new ActionRowBuilder()
                        .addComponents(buttons.slice(i, i + 5));
                    rows.push(row);
                }
                
                await message.edit({ components: rows });
                restoredCount++;
            } catch (error) {
                console.error(`Failed to restore role buttons for message ${messageId}:`, error.message);
                failedCount++;
            }
        }
    }
    
    if (restoredCount > 0) {
        console.log(`Restored ${restoredCount} role button configuration(s)`);
    }
    if (failedCount > 0) {
        console.log(`Failed to restore ${failedCount} role button configuration(s)`);
    }
}

client.on(Events.InteractionCreate, async interaction => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        
        if (!command) return;
        
        try {
            await command.execute(interaction, config, saveConfig);
        } catch (error) {
            console.error(error);
            const reply = { content: 'There was an error executing this command!', ephemeral: true };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(reply);
            } else {
                await interaction.reply(reply);
            }
        }
    } else if (interaction.isButton()) {
        const buttonId = interaction.customId;
        
        if (buttonId.startsWith('role_')) {
            const roleId = buttonId.replace('role_', '');
            const role = interaction.guild.roles.cache.get(roleId);
            
            if (!role) {
                return interaction.reply({ content: 'This role no longer exists!', ephemeral: true });
            }
            
            const member = interaction.member;
            
            try {
                if (member.roles.cache.has(roleId)) {
                    await member.roles.remove(roleId);
                    await interaction.reply({ content: `Removed the **${role.name}** role!`, ephemeral: true });
                } else {
                    await member.roles.add(roleId);
                    await interaction.reply({ content: `Added the **${role.name}** role!`, ephemeral: true });
                }
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'I don\'t have permission to manage this role!', ephemeral: true });
            }
        }
    }
});

client.on(Events.MessageCreate, async message => {
    if (message.author.bot) return;
    
    const content = message.content.toLowerCase();
    const guildId = message.guild.id;
    
    if (config.autoResponders[guildId]) {
        for (const [keyword, response] of Object.entries(config.autoResponders[guildId])) {
            if (content.includes(keyword.toLowerCase())) {
                try {
                    await message.reply(response);
                } catch (error) {
                    console.error('Error sending auto-response:', error);
                }
                break;
            }
        }
    }
    
    if (config.autoReactions[guildId]) {
        for (const [keyword, emoji] of Object.entries(config.autoReactions[guildId])) {
            if (content.includes(keyword.toLowerCase())) {
                try {
                    await message.react(emoji);
                } catch (error) {
                    console.error('Error adding auto-reaction:', error);
                }
            }
        }
    }
});

const token = process.env.DISCORD_TOKEN;

if (!token) {
    console.error('ERROR: DISCORD_TOKEN environment variable is not set!');
    console.error('Please set your Discord bot token using the DISCORD_TOKEN secret.');
    process.exit(1);
}

client.login(token).catch(error => {
    console.error('Failed to login:', error);
    process.exit(1);
});
