const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-responder')
        .setDescription('Add an auto-responder for a specific keyword')
        .addStringOption(option =>
            option.setName('keyword')
                .setDescription('The keyword to trigger the response')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('response')
                .setDescription('The response message')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const keyword = interaction.options.getString('keyword');
        const response = interaction.options.getString('response');
        const guildId = interaction.guild.id;
        
        if (!config.autoResponders[guildId]) {
            config.autoResponders[guildId] = {};
        }
        
        config.autoResponders[guildId][keyword] = response;
        saveConfig(config);
        
        await interaction.reply({
            content: `Auto-responder added!\n**Keyword:** ${keyword}\n**Response:** ${response}`,
            ephemeral: true
        });
    },
};
