const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-role-buttons')
        .setDescription('Remove role buttons from a message')
        .addStringOption(option =>
            option.setName('message-link')
                .setDescription('The Discord message link with role buttons to remove')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const messageLink = interaction.options.getString('message-link');
        
        const linkRegex = /https:\/\/discord\.com\/channels\/(\d+)\/(\d+)\/(\d+)/;
        const match = messageLink.match(linkRegex);
        
        if (!match) {
            return await interaction.reply({
                content: 'Invalid message link! Please provide a valid Discord message link.',
                ephemeral: true
            });
        }
        
        const [, guildId, channelId, messageId] = match;
        
        if (guildId !== interaction.guild.id) {
            return await interaction.reply({
                content: 'This message is from a different server!',
                ephemeral: true
            });
        }
        
        if (!config.roleButtons[guildId] || !config.roleButtons[guildId][messageId]) {
            return await interaction.reply({
                content: 'No role button configuration found for this message.',
                ephemeral: true
            });
        }
        
        try {
            const channel = await interaction.guild.channels.fetch(channelId);
            const message = await channel.messages.fetch(messageId);
            
            await message.edit({ components: [] });
            
            delete config.roleButtons[guildId][messageId];
            saveConfig(config);
            
            await interaction.reply({
                content: 'Role buttons removed from the message!',
                ephemeral: true
            });
            
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'Failed to fetch or edit the message. Make sure I have access to that channel and the message exists!',
                ephemeral: true
            });
        }
    },
};
