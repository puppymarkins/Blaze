const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-reaction')
        .setDescription('Add an auto-reaction for a specific keyword')
        .addStringOption(option =>
            option.setName('keyword')
                .setDescription('The keyword to trigger the reaction')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('The emoji to react with (e.g., 👍 or :custom_emoji:)')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const keyword = interaction.options.getString('keyword');
        const emoji = interaction.options.getString('emoji');
        const guildId = interaction.guild.id;
        
        if (!config.autoReactions[guildId]) {
            config.autoReactions[guildId] = {};
        }
        
        config.autoReactions[guildId][keyword] = emoji;
        saveConfig(config);
        
        await interaction.reply({
            content: `Auto-reaction added!\n**Keyword:** ${keyword}\n**Emoji:** ${emoji}`,
            ephemeral: true
        });
    },
};
