const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-responder')
        .setDescription('Remove an auto-responder')
        .addStringOption(option =>
            option.setName('keyword')
                .setDescription('The keyword to remove')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const keyword = interaction.options.getString('keyword');
        const guildId = interaction.guild.id;
        
        if (!config.autoResponders[guildId] || !config.autoResponders[guildId][keyword]) {
            return await interaction.reply({
                content: `No auto-responder found for keyword: **${keyword}**`,
                ephemeral: true
            });
        }
        
        delete config.autoResponders[guildId][keyword];
        saveConfig(config);
        
        await interaction.reply({
            content: `Auto-responder removed for keyword: **${keyword}**`,
            ephemeral: true
        });
    },
};
