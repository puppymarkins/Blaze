const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list-reactions')
        .setDescription('List all auto-reactions for this server')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const guildId = interaction.guild.id;
        
        if (!config.autoReactions[guildId] || Object.keys(config.autoReactions[guildId]).length === 0) {
            return await interaction.reply({
                content: 'No auto-reactions configured for this server.',
                ephemeral: true
            });
        }
        
        const embed = new EmbedBuilder()
            .setTitle('Auto-Reactions')
            .setColor(0x00FF00)
            .setDescription('List of all active auto-reactions')
            .setTimestamp();
        
        for (const [keyword, emoji] of Object.entries(config.autoReactions[guildId])) {
            embed.addFields({
                name: `Keyword: ${keyword}`,
                value: `Emoji: ${emoji}`,
                inline: false
            });
        }
        
        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
