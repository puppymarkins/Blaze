const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-reaction')
        .setDescription('Remove an auto-reaction')
        .addStringOption(option =>
            option.setName('keyword')
                .setDescription('The keyword to remove')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const keyword = interaction.options.getString('keyword');
        const guildId = interaction.guild.id;
        
        if (!config.autoReactions[guildId] || !config.autoReactions[guildId][keyword]) {
            return await interaction.reply({
                content: `No auto-reaction found for keyword: **${keyword}**`,
                ephemeral: true
            });
        }
        
        delete config.autoReactions[guildId][keyword];
        saveConfig(config);
        
        await interaction.reply({
            content: `Auto-reaction removed for keyword: **${keyword}**`,
            ephemeral: true
        });
    },
};
