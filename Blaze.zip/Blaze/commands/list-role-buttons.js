const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list-role-buttons')
        .setDescription('List all role button configurations for this server')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const guildId = interaction.guild.id;
        
        if (!config.roleButtons[guildId] || Object.keys(config.roleButtons[guildId]).length === 0) {
            return await interaction.reply({
                content: 'No role button configurations for this server.',
                ephemeral: true
            });
        }
        
        const embed = new EmbedBuilder()
            .setTitle('Role Button Configurations')
            .setColor(0x00FF00)
            .setDescription('List of all configured role buttons')
            .setTimestamp();
        
        for (const [messageId, data] of Object.entries(config.roleButtons[guildId])) {
            const buttonList = data.buttons.map(b => `${b.label} → ${b.roleName}`).join('\n');
            const messageLink = `https://discord.com/channels/${guildId}/${data.channelId}/${messageId}`;
            
            embed.addFields({
                name: `Message ID: ${messageId}`,
                value: `[Jump to Message](${messageLink})\n${buttonList}`,
                inline: false
            });
        }
        
        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
