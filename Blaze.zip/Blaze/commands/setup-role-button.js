const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-role-button')
        .setDescription('Create a message with role assignment buttons')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to send the role button message to')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role1')
                .setDescription('First role to assign')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('label1')
                .setDescription('Button label for first role')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message')
                .setDescription('The message text to display above the buttons')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role2')
                .setDescription('Second role to assign')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('label2')
                .setDescription('Button label for second role')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role3')
                .setDescription('Third role to assign')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('label3')
                .setDescription('Button label for third role')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role4')
                .setDescription('Fourth role to assign')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('label4')
                .setDescription('Button label for fourth role')
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('role5')
                .setDescription('Fifth role to assign')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('label5')
                .setDescription('Button label for fifth role')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const channel = interaction.options.getChannel('channel');
        const messageText = interaction.options.getString('message') || 'Click a button to get a role!';
        const guildId = interaction.guild.id;
        
        const buttons = [];
        const roles = [];
        
        for (let i = 1; i <= 5; i++) {
            const role = interaction.options.getRole(`role${i}`);
            const label = interaction.options.getString(`label${i}`);
            
            if (role && label) {
                roles.push(role);
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`role_${role.id}`)
                        .setLabel(label)
                        .setStyle(ButtonStyle.Primary)
                );
            }
        }
        
        if (buttons.length === 0) {
            return await interaction.reply({
                content: 'You must provide at least one role and label!',
                ephemeral: true
            });
        }
        
        const rows = [];
        for (let i = 0; i < buttons.length; i += 5) {
            const row = new ActionRowBuilder()
                .addComponents(buttons.slice(i, i + 5));
            rows.push(row);
        }
        
        try {
            const sentMessage = await channel.send({
                content: messageText,
                components: rows
            });
            
            if (!config.roleButtons[guildId]) {
                config.roleButtons[guildId] = {};
            }
            
            const buttonConfig = roles.map((role, i) => ({
                roleId: role.id,
                roleName: role.name,
                label: buttons[i].data.label
            }));
            
            config.roleButtons[guildId][sentMessage.id] = {
                channelId: channel.id,
                messageId: sentMessage.id,
                buttons: buttonConfig
            };
            
            saveConfig(config);
            
            const roleList = roles.map((r, i) => `${buttons[i].data.label} → ${r.name}`).join('\n');
            
            await interaction.reply({
                content: `Role button message created in ${channel}!\n\n**Roles configured:**\n${roleList}`,
                ephemeral: true
            });
            
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: 'Failed to send the message. Make sure I have permission to send messages in that channel!',
                ephemeral: true
            });
        }
    },
};
