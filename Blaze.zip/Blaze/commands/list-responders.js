const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list-responders')
        .setDescription('List all auto-responders for this server')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
    
    async execute(interaction, config, saveConfig) {
        const guildId = interaction.guild.id;
        
        if (!config.autoResponders[guildId] || Object.keys(config.autoResponders[guildId]).length === 0) {
            return await interaction.reply({
                content: 'No auto-responders configured for this server.',
                ephemeral: true
            });
        }
        
        const embed = new EmbedBuilder()
            .setTitle('Auto-Responders')
            .setColor(0x00FF00)
            .setDescription('List of all active auto-responders')
            .setTimestamp();
        
        for (const [keyword, response] of Object.entries(config.autoResponders[guildId])) {
            embed.addFields({
                name: `Keyword: ${keyword}`,
                value: `Response: ${response}`,
                inline: false
            });
        }
        
        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
